//
//  mycover_appTests.swift
//  mycover-appTests
//
//  Created by Alumno on 22/10/24.
//

import Testing
@testable import mycover_app

struct mycover_appTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
